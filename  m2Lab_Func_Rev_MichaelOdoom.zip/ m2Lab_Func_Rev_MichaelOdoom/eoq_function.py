# A brief description of the project
# This file contains the `eoq` function, which calculates the Economic Order Quantity (EOQ).
# The function accounts for the minimum order size if provided.
# Date: Feb. 07, 2025
# CSC121 m2Lab – Function Review
# Michael Odoom

# eoq_function.py

def eoq(demand, reorderCost, holdingCost, minOrder=0):
    """
    Calculate the Economic Order Quantity (EOQ).

    Parameters:
    - demand (float): Projected demand (units/year).
    - reorderCost (float): Reorder cost ($/order).
    - holdingCost (float): Holding cost ($/year/unit).
    - minOrder (float, optional): Minimum order size (units/order). Defaults to 0.

    Returns:
    - float: The calculated EOQ or the minimum order size if it is higher.
    """
    # Calculate EOQ
    eoq_value = (2 * demand * reorderCost / holdingCost) ** 0.5
    # Return the larger value between EOQ and minimum order size
    return max(eoq_value, minOrder)

