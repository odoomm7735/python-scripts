# A brief description of the project
# This program calculates the Economic Order Quantity (EOQ) using a modularized approach.
# The program is menu-driven and allows users to calculate EOQ based on user inputs.
# Date: Feb. 07, 2025
# CSC121 m2Lab – Function Review
# Michael Odoom

# Pseudocode:
# 1. Start Program
#    - Display menu options.
#    - Loop until the user chooses to exit.
# 2. Menu Options:
#    - Option 1: Calculate EOQ
#      - Prompt user for inputs: demand, reorder cost, holding cost, and minimum order size.
#      - Call the `eoq` function from `eoq_function.py` to calculate the result.
#      - Display the EOQ and adjusted order quantity.
#    - Option 2: Exit the program.
# 3. End Program
#    - Exit when the user selects option 2.

# main_program.py

# Import the eoq function from the separate file
from eoq_function import eoq

def display_menu():
    """Display the program menu."""
    print("\nEconomic Order Quantity (EOQ) Calculator")
    print("1. Calculate EOQ")
    print("2. Exit")

def calculate_eoq():
    """Prompt user for inputs and calculate EOQ."""
    try:
        # Get user inputs
        demand = float(input("Enter the projected demand (units/year): "))
        reorderCost = float(input("Enter the reorder cost ($/order): "))
        holdingCost = float(input("Enter the holding cost ($/year/unit): "))
        minOrder = float(input("Enter the minimum order size (units/order): "))

        # Call the eoq function
        result = eoq(demand, reorderCost, holdingCost, minOrder)

        # Display results
        print("\nResults:")
        print(f"Economic Order Quantity (EOQ): {round(result)} units")
        print(f"Adjusted Order Quantity: {result} units")
    except ValueError:
        print("Invalid input. Please enter numeric values.")

def main():
    """Main function to run the program."""
    while True:
        display_menu()
        choice = input("Enter your choice (1/2): ")

        if choice == "1":
            calculate_eoq()
        elif choice == "2":
            print("Exiting the program. Goodbye!")
            break
        else:
            print("Invalid choice. Please select 1 or 2.")

# Run the program
if __name__ == "__main__":
    main()