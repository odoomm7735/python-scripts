#Breakdown below

"""
Pseudocode and Description
Bash Script: provision_instances.sh
Description:
This script automates the provisioning of an AWS EC2 instance, waits until the instance is in the running state, and tags the instance 
with key-value metadata.

Pseudocode:

Set Variables: Define AWS region, AMI ID, instance type, key name, and security group.
Launch EC2 Instance:
Execute the AWS CLI command to launch an instance and store the instance ID.
Wait for Instance State:
Use aws ec2 wait to wait until the instance status becomes "running."
Tag the Instance:
Use aws ec2 create-tags to add a custom tag (Environment: Development) to the instance.
Print Success Message: Display a success message when provisioning is complete.
Python Script: cost_report.py
Description:
This script uses the AWS Cost Explorer API to generate a daily cost report for the last seven days and prints the results to the 
console.

Pseudocode:

Initialize AWS Cost Explorer Client:
Create a boto3 client for AWS Cost Explorer.
Define Time Period:
Get the current date and compute the start date for the past 7 days.
Request Cost Data:
Use get_cost_and_usage() with the time period and metric (UnblendedCost).
Parse Response:
Loop through the API response to extract the date and cost for each day.
Print Cost Report:
Display the cost in a formatted way for each day.

"""

"""
Run:
    Set up AWS CLI: Configure AWS CLI with credentials.
    aws configure
Execute the Bash Script:
    bash provision_instances.sh
Run the Python Cost Report Script:
    python3 cost_report.py

Enhancements
*   Add exception handling in Python for API errors.
*   Integrate SNS notifications for the cost report.
*   Schedule these scripts using cron.
"""