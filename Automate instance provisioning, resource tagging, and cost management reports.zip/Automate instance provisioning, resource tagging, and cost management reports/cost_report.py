import boto3
from datetime import datetime, timedelta

def generate_cost_report():
    # Initialize Cost Explorer client
    client = boto3.client('ce', region_name='us-east-1')

    # Define time period (last 7 days)
    end_date = datetime.utcnow().date()
    start_date = end_date - timedelta(days=7)

    # AWS Cost Explorer request
    response = client.get_cost_and_usage(
        TimePeriod={
            'Start': start_date.strftime('%Y-%m-%d'),
            'End': end_date.strftime('%Y-%m-%d')
        },
        Granularity='DAILY',
        Metrics=['UnblendedCost']
    )

    print("AWS Cost Report (Last 7 Days):")
    for result in response['ResultsByTime']:
        date = result['TimePeriod']['Start']
        cost = result['Total']['UnblendedCost']['Amount']
        print(f"{date}: ${float(cost):.2f}")

if __name__ == "__main__":
    generate_cost_report()