#!/bin/bash

# Variables
REGION="us-east-1"
AMI_ID="ami-0c55b159cbfafe1f0" # Example Amazon Linux AMI
INSTANCE_TYPE="t2.micro"
KEY_NAME="my-key-pair"
SECURITY_GROUP="sg-0123456789abcdef0"
TAG_KEY="Environment"
TAG_VALUE="Development"

# Provision EC2 instance
echo "Launching EC2 instance..."
INSTANCE_ID=$(aws ec2 run-instances \
  --region "$REGION" \
  --image-id "$AMI_ID" \
  --instance-type "$INSTANCE_TYPE" \
  --key-name "$KEY_NAME" \
  --security-group-ids "$SECURITY_GROUP" \
  --query 'Instances[0].InstanceId' \
  --output text)

echo "Instance launched: $INSTANCE_ID"

# Wait for the instance to be running
echo "Waiting for instance to reach 'running' state..."
aws ec2 wait instance-running --instance-ids "$INSTANCE_ID"

echo "Tagging the instance with $TAG_KEY: $TAG_VALUE"
aws ec2 create-tags \
  --resources "$INSTANCE_ID" \
  --tags Key="$TAG_KEY",Value="$TAG_VALUE"

echo "Instance provisioning and tagging complete."